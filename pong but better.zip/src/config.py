import pygame
import json
import random
import math
from pygame.locals import *
pygame.init()

clock = pygame.time.Clock()
static = json.loads(open('data/json/static.json').read())
settings = json.loads(open('data/json/settings.json').read())
controls = json.loads(open('data/json/controls.json').read())
pygame.display.set_icon(pygame.image.load('data/textures/icon.bmp'))
pygame.display.set_caption('PongButBetter', 'Pong')
sc = pygame.display.set_mode((static['public']['create']['window']['size'][0],
                              static['public']['create']['window']['size'][1]), pygame.RESIZABLE)
gs = pygame.Surface((sc.get_width() // 2, sc.get_height() // 2))

default_tps = static['public']['render']['tps']
fps = settings['public']['render']['fps']
font16 = pygame.font.Font(static['protected']['font']['default'], 16)
font8 = pygame.font.Font(static['protected']['font']['default'], 8)
font4 = pygame.font.Font(static['protected']['font']['default'], 6)
font24 = pygame.font.Font(static['protected']['font']['default'], 24)
font12 = pygame.font.Font(static['protected']['font']['default'], 12)

real_up_1_key = controls['real']['first']['up']
real_down_1_key = controls['real']['first']['down']

real_up_2_key = controls['real']['second']['up']
real_down_2_key = controls['real']['second']['down']
lights = {
    "white": pygame.image.load('data/map/light/white_light.png')
}

prerender_light = {
    "player": pygame.transform.scale(lights['white'], (48, 48)),
    "_player": pygame.transform.scale(lights['white'], (56, 86)),
    "_player_": pygame.transform.scale(lights['white'], (56, 86)),
    "player_": pygame.transform.scale(lights['white'], (48, 48)),
}

prerender_light['player'].set_alpha(20)
prerender_light['_player'].set_alpha(20)
prerender_light['player_'].set_alpha(235)
prerender_light['_player_'].set_alpha(235)

pygame.mixer.music.load(random.choice(static['public']['music']))
pygame.mixer.music.play(-1)
