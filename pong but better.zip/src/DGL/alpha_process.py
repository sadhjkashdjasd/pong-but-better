def trs(surf, alpha):
    surf = surf.copy()
    surf.set_alpha(alpha)
    return surf
