from src.config import *


class Player:
    def __init__(self, mode, pos, nickname):
        self.mode = mode
        self.pos = pos
        self.nickname = nickname
        self.speed = [0, 0]

    def draw(self):
        pygame.draw.rect(gs, (255, 255, 255), (self.pos[0], self.pos[1], 16, 48))

    def control(self, keys, delta, ball_pos, ball_energy):
        self.speed = [0.01, 0]
        if self.mode == '1real':
            if real_up_1_key in keys and self.pos[1] > 0:
                self.pos[1] -= 5 / delta
                self.speed[1] = -5
            elif real_down_1_key in keys and self.pos[1] < gs.get_height() - 48:
                self.pos[1] += 5 / delta
                self.speed[1] = 5

        if self.mode == '2real':
            if real_up_2_key in keys and self.pos[1] > 0:
                self.pos[1] -= 5 / delta
                self.speed[1] = -5
            elif real_down_2_key in keys and self.pos[1] < gs.get_height() - 48:
                self.pos[1] += 5 / delta
                self.speed[1] = 5

        if self.mode == '2ai':
            if gs.get_width() // 2 < ball_pos[0] < self.pos[0]:
                if abs(ball_energy[0]) > 1 or abs(ball_energy[1]) > 1:
                    if abs(ball_energy[0]) < 6 or abs(ball_energy[1]) < 6:
                        if self.pos[1] < ball_pos[1]:
                            self.pos[1] += (2.5 + (random.randint(-2, 2) / 10)) / delta
                            self.speed[1] = 2.5

                        if self.pos[1] > ball_pos[1]:
                            self.pos[1] -= (2.5 + (random.randint(-2, 2) / 10)) / delta
                            self.speed[1] = -2.5
                    else:
                        if self.pos[1] < ball_pos[1]:
                            self.pos[1] += (3.3 + (random.randint(-2, 2) / 10)) / delta
                            self.speed[1] = 3.3

                        if self.pos[1] > ball_pos[1]:
                            self.pos[1] -= (3.3 + (random.randint(-2, 2) / 10)) / delta
                            self.speed[1] = -3.3

                if self.pos[1] < 0:
                    self.pos[1] = 0
                if self.pos[1] > gs.get_height() - 48:
                    self.pos[1] = gs.get_height() - 48

        if self.mode == '1ai':
            if ball_pos[0] > self.pos[0] and ball_pos[0] > gs.get_width() // 2:
                if abs(ball_energy[0]) > 1 or abs(ball_energy[1]) > 1:
                    if abs(ball_energy[0]) < 6 or abs(ball_energy[1]) < 6:
                        if self.pos[1] < ball_pos[1]:
                            self.pos[1] += (2.5 + (random.randint(-2, 2) / 10)) / delta
                            self.speed[1] = 2.5

                        if self.pos[1] > ball_pos[1]:
                            self.pos[1] -= (2.5 + (random.randint(-2, 2) / 10)) / delta
                            self.speed[1] = -2.5
                    else:
                        if self.pos[1] < ball_pos[1]:
                            self.pos[1] += (3.3 + (random.randint(-2, 2) / 10)) / delta
                            self.speed[1] = 3.3

                        if self.pos[1] > ball_pos[1]:
                            self.pos[1] -= (3.3 + (random.randint(-2, 2) / 10)) / delta
                            self.speed[1] = -3.3

                if self.pos[1] < 0:
                    self.pos[1] = 0
                if self.pos[1] > gs.get_height() - 48:
                    self.pos[1] = gs.get_height() - 48

    def collide_with_ball(self, ball_pos, ball_energy) -> bool:
        if pygame.Rect(self.pos[0], self.pos[1], 16, 48).colliderect(pygame.Rect(ball_pos[0] - 5,
                                                                                 ball_pos[1] - 5, 20, 20)):
            ball_energy[0] *= -1.1
            ball_energy[1] *= -1.1
            ball_energy[0] += self.speed[0] / 2
            ball_energy[1] += self.speed[1] / 2

            return True
        return False
