from src.config import *

hit_sound0 = pygame.mixer.Sound('data/sound/border_hit_0.wav')
hit_sound1 = pygame.mixer.Sound('data/sound/border_hit_1.wav')
hit_sound2 = pygame.mixer.Sound('data/sound/border_hit_2.wav')

player_hit_sound0 = pygame.mixer.Sound('data/sound/player_hit_0.wav')
player_hit_sound1 = pygame.mixer.Sound('data/sound/player_hit_1.wav')
player_hit_sound2 = pygame.mixer.Sound('data/sound/player_hit_2.wav')

button_pressed_sound0 = pygame.mixer.Sound('data/sound/button_pressed_0.wav')
button_pressed_sound1 = pygame.mixer.Sound('data/sound/button_pressed_1.wav')
button_pressed_sound2 = pygame.mixer.Sound('data/sound/button_pressed_2.wav')


def play_border_hit_sound():
    s = random.randint(0, 2)
    if s == 0:
        hit_sound0.play()
    elif s == 1:
        hit_sound1.play()
    elif s == 2:
        hit_sound2.play()


def play_player_hit_sound():
    s = random.randint(0, 2)
    if s == 0:
        player_hit_sound0.play()
    elif s == 1:
        player_hit_sound1.play()
    elif s == 2:
        player_hit_sound2.play()


def play_button_pressed_sound():
    s = random.randint(0, 2)
    if s == 0:
        button_pressed_sound0.play()
    elif s == 1:
        button_pressed_sound1.play()
    elif s == 2:
        button_pressed_sound2.play()
