from src.config import *


def rect_surf(color, x, y, outline=0, border_radius=0):
    surf = pygame.Surface((x, y))
    if color == (0, 0, 0):
        color = (1, 1, 1)
    surf.set_colorkey((0, 0, 0))

    pygame.draw.rect(surf, color, (0, 0, x, y), outline, border_radius=border_radius)
    surf.convert_alpha()

    return surf


class Particle:
    def __init__(self, pos: list, radius, speed, speed_of_sizing, image=False, color=(255, 0, 0), reflection=True,
                 r_alpha=100):
        self.speed_of_sizing = speed_of_sizing
        self.alive = True
        self.pos = pos
        self.image = image
        self.color = color
        self.reflection = reflection
        self.radius = radius
        self.speedx, self.speedy = speed
        if self.image and self.reflection:
            self.ref = self.image.copy()
            self.ref.set_alpha(100)
        self.r_alpha = r_alpha

    def draw(self, scroll):
        if not self.image:
            try:
                pygame.draw.circle(gs, self.color, [self.pos[0] - scroll[0], self.pos[1] - scroll[1]], self.radius)
                if self.reflection:
                    gs.blit(circle_surf(self.color, self.radius, alpha=self.r_alpha),
                            anti_shader(self.pos[0] - scroll[0], self.pos[1] - scroll[1]))
            except:
                print(f'Failed to Draw particle {self.__class__}')

        if self.image:
            # noinspection PyTypeChecker
            gs.blit(pygame.transform.scale(self.image, (int(self.radius), int(self.radius))), self.pos)
            if self.reflection:
                gs.blit(pygame.transform.scale(self.ref, (int(self.radius), int(self.radius))),
                        anti_shader(self.pos[0], self.pos[1]))

    def update(self, delta):
        self.pos[0] += self.speedx / delta
        self.pos[1] += self.speedy / delta
        self.radius -= self.speed_of_sizing / delta
        if self.radius <= 0:
            self.alive = False


def shader(x, y, sp=1, spsp=1):
    x, y = x - (sp * math.pi * 2) * math.sin(spsp) * 2, y
    return x, y


def double_shader(x, y, sp=1, spsp=1):
    x, y = x - (sp * math.pi * 2) * math.sin(spsp) * 2, y + (sp * math.pi * 2) * math.sin(spsp) * 2
    return x, y


def anti_double_shader(x, y, sp=1, spsp=1):
    x, y = x + (sp * math.pi * 2) * math.sin(spsp) * 2, y - (sp * math.pi * 2) * math.sin(spsp) * 2
    return x, y


def anti_shader(x, y, sp=1, spsp=1):
    x, y = x + (sp * math.pi * 0.6) * math.sin(spsp) * 2, y
    return x, y


def anti_yshader(x, y, sp=1, spsp=1):
    x, y = x, y + (sp * math.pi * 2) * math.sin(spsp) * 2
    return x, y


def circle_surf(clr, radius, alpha=255):
    surf = pygame.Surface((radius * 2, radius * 2))
    pygame.draw.circle(surf, clr, (radius, radius), radius)
    surf.set_alpha(alpha)
    surf.set_colorkey((0, 0, 0))
    return surf
