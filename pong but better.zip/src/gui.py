import pygame

from src.config import *


class Button:
    def __init__(self, x, y):
        self.x, self.y = x, y
        self.font = pygame.font.Font(None, 24)
        self.text_ = 'Button' + self.__str__()
        self._color_text = (255, 255, 255)
        self.text = self.font.render(self.text_, True, self._color_text)
        self.sprite = pygame.Surface((1, 1))
        self.collide_ = False
        self.text_reflection = False
        self.text__ = self.text.copy()
        self.text__.set_alpha(120)
        self.x_, self.y_ = (0, 0)
        self.animation_type = 'left'
        self.animation_mm = 15
        self.image = pygame.Surface((1, 1))
        self.image_reflection = False
        self.image__ = self.image.copy()
        self.image__.set_alpha(120)
        self.changed = True

    def draw(self):
        if self.text_reflection:
            gs.blit(self.text__, (self.x + 3 - self.x_, self.y + 2 - self.y_))

        if self.image_reflection:
            gs.blit(self.image__, (self.x + 3 - self.x_, self.y + 2 - self.y_))

        gs.blit(self.text, (self.x - self.x_, self.y - self.y_))
        gs.blit(self.image, (self.x - self.x_, self.y - self.y_))

    def update_data(self, typename):
        if typename == 'text':
            self.text = self.font.render(self.text_, True, self._color_text)
            self.text__ = self.text.copy()
            self.text__.set_alpha(120)
        if typename == 'image':
            self.image__ = self.image.copy()
            self.image__.set_alpha(120)

    def collide(self, mx, my):
        if pygame.Rect(self.x, self.y, self.sprite.get_width(), self.sprite.get_height()).collidepoint(mx, my):
            return True

        return False

    def animate(self, delta):
        if self.animation_type == 'left':
            if self.collide_:
                self.x_ += (((self.x - self.x_) - (self.x - self.animation_mm)) / 15) / delta
            else:
                self.x_ += (((self.x - self.x_) - self.x) / 10) / delta

        if self.animation_type == 'right':
            if self.collide_:
                self.x_ += (((self.x - self.x_) - (self.x + self.animation_mm)) / 15) / delta
            else:
                self.x_ += (((self.x - self.x_) - self.x) / 10) / delta

        if self.animation_type == 'down':
            if self.collide_:
                self.y_ += (((self.y - self.y_) - (self.y + self.animation_mm)) / 15) / delta
            else:
                self.y_ += (((self.y - self.y_) - self.y) / 10) / delta

        if self.animation_type == 'up':
            if self.collide_:
                self.y_ += (((self.y - self.y_) - (self.y - self.animation_mm)) / 15) / delta
            else:
                self.y_ += (((self.y - self.y_) - self.y) / 10) / delta
